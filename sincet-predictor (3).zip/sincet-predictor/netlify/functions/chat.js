// Netlify function: POST {prompt} -> {text}. Set ANTHROPIC_API_KEY in Netlify > Site settings > Environment variables.
exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: JSON.stringify({ text: "POST only" }) };
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return { statusCode: 500, body: JSON.stringify({ text: "ANTHROPIC_API_KEY is not set on the server." }) };
  let prompt = "";
  try { prompt = String(JSON.parse(event.body || "{}").prompt || "").slice(0, 6000); } catch (e) {}
  if (!prompt) return { statusCode: 400, body: JSON.stringify({ text: "Empty question." }) };
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 800, messages: [{ role: "user", content: prompt }] }),
    });
    const j = await r.json();
    const text = (j.content || []).map((c) => c.text || "").join("");
    return { statusCode: 200, body: JSON.stringify({ text: text || (j.error && j.error.message) || "No answer" }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ text: "AI server error." }) };
  }
};
