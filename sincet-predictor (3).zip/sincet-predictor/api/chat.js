// Vercel serverless function: POST {prompt} -> {text}. Set ANTHROPIC_API_KEY in Vercel > Settings > Environment Variables.
module.exports = async (req, res) => {
  if (req.method !== "POST") return res.status(405).json({ text: "POST only" });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ text: "ANTHROPIC_API_KEY is not set on the server." });
  const prompt = String((req.body && req.body.prompt) || "").slice(0, 6000);
  if (!prompt) return res.status(400).json({ text: "Empty question." });
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 800, messages: [{ role: "user", content: prompt }] }),
    });
    const j = await r.json();
    const text = (j.content || []).map((c) => c.text || "").join("");
    res.status(200).json({ text: text || (j.error && j.error.message) || "No answer" });
  } catch (e) {
    res.status(500).json({ text: "AI server error." });
  }
};
