SINCET Student Performance Prediction System - 3 separate portals
==================================================================
student.html (also index.html)  -> Student portal
faculty.html                     -> Faculty portal
admin.html                       -> Admin portal  (keep this link private, you can rename the file)
Each portal shows only its own login page, no portal selection. They share the same data when opened
from the same website in the same browser.

Deploy: drag the whole folder to https://app.netlify.com/drop  (or upload to GitHub and import in Vercel).
Admin username MOHANRAJ: search "MOHANRAJ" in admin.html to change the password.

AI study chat (student > AI insights)
- Needs an AI server. Two ready functions are included:
  Vercel : api/chat.js            Netlify : netlify/functions/chat.js
- Add the environment variable ANTHROPIC_API_KEY (from console.anthropic.com) and redeploy. Optional: ANTHROPIC_MODEL.
- This spends your API credits for every question, so keep the website link to students only.

Notes
- Data is stored in the browser (localStorage): not shared between devices. For real college use add a database (Supabase).
- Admin password is in client code: not secure for public hosting.
- Parent alerts open WhatsApp/SMS with the message ready (manual Send). Automatic sending needs an SMS gateway server.
